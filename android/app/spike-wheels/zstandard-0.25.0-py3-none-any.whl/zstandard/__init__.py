"""hachimi phone-side stub: satisfies pip; import raises for ZstdCompressor
consumers whose guard (try/except ImportError) then disables compression.
"""
raise ImportError("zstandard is not available on this phone build (compression disabled)")
