"""xxhash 纯 Python 替身（hachimi phone-side shim wheel）。

langgraph 只消费 ``xxh3_128_hexdigest``（pregel 状态版本指纹——只要求确定性
128 位摘要，不要求 xxh3 位级兼容）。本实现用 hashlib.blake2b(digest_size=16)
满足语义；与 PC 真实 xxhash 的摘要值不互通（无跨机语义，无影响）。
真实 C 扩展若需要，可走 Chaquopy target 头文件 + NDK 自建。
"""
from hashlib import blake2b as _b2


def xxh3_128_hexdigest(data, *, seed=0):
    """确定性 128 位十六进制摘要（语义替身，非 xxh3 位级兼容）。"""
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    return _b2(data, digest_size=16, key=b"" if not seed else str(seed).encode()).hexdigest()


def xxh64(data, *, seed=0):
    class _H:
        def __init__(self, d):
            self._d = d
        def hexdigest(self):
            return self._d()[:16]
        def intdigest(self):
            return int(self._d()[:16], 16)
    d = lambda: xxh3_128_hexdigest(data, seed=seed)
    return _H(d)


def xxh3_64_hexdigest(data, *, seed=0):
    return xxh3_128_hexdigest(data, seed=seed)[:16]
